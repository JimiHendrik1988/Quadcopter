package de.lazyzero.kkMulticopterFlashTool.gui;

import static lu.tudor.santec.i18n.Translatrix._;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.logging.Logger;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

import de.lazyzero.kkMulticopterFlashTool.KKMulticopterFlashTool;
import de.lazyzero.kkMulticopterFlashTool.utils.EEprom.EEprom;
import de.lazyzero.kkMulticopterFlashTool.utils.EEprom.EEpromListener;

public class EEpromResetPanel extends JPanel implements ActionListener, PropertyChangeListener, EEpromListener{
	
	private static final long serialVersionUID = 1L;
	private KKMulticopterFlashTool parent;
	private CellConstraints cc;
	private Logger logger = KKMulticopterFlashTool.getLogger();
	private EEprom eeprom;
	private JLabel warning;
	private JButton resetButton;
	
	public EEpromResetPanel(KKMulticopterFlashTool parent) {
		this.parent = parent;
		
		init();
		this.addPropertyChangeListener(this);
	}

	private void init() {
		//create the CellContraints
		cc  = new CellConstraints();
		
		// create the Layout for Panel this
		String panelColumns = "3dlu,fill:pref:grow,3dlu,pref,3dlu";
		String panelRows = "pref";
		FormLayout panelLayout = new FormLayout(panelColumns, panelRows);
		this.setLayout(panelLayout);
		
		this.setBorder(new TitledBorder(_("EEpromResetPanel.title")));
		
		this.warning = new JLabel(_("EEpromResetPanel.warning"));
		this.resetButton = new JButton(_("EEpromResetPanel.resetButton"));
		this.resetButton.addActionListener(this);
		
		this.add(warning, cc.xy(2, 1));
		this.add(resetButton, cc.xy(4, 1));
		
	}

	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		if (evt.getPropertyName().equals(ControllerPanel.CONTROLLER_CHANGED)) {
			this.eeprom = new EEprom(parent.getController().getEepromSize());
			logger.info("EEprom size set to: " + parent.getController().getEepromSize());
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(resetButton)){
			logger.info("RESET the EEprom!!!");
			parent.clearText();
			eeprom.writeRawEEprom();
			//TODO Disable all
			parent.flashEEprom(this);
			
			//TODO Enable all
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void EEpromState(int state) {
		if (state < 0) {
			parent.setSelectedTabIndex(0);
		}
	}
}
