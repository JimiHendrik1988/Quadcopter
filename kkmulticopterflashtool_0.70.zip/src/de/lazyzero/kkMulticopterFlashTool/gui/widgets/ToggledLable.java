package de.lazyzero.kkMulticopterFlashTool.gui.widgets;

import java.awt.Color;

import javax.swing.JLabel;

public class ToggledLable extends JLabel {

	private static final long serialVersionUID = 1L;
	private Color fontColor = Color.LIGHT_GRAY;
	
	public ToggledLable(String s, boolean isEnabled, Color fg, Color bg) {
		super(s);
		if (bg.getBlue() == 3 && bg.getRed() == 3 && bg.getGreen() == 3) {
			fontColor = Color.DARK_GRAY;
		}
		this.setForeground(isEnabled?fg:fontColor);
		this.setOpaque(true);
		this.setBackground(bg);
		this.setFont(this.getFont().deriveFont(this.getFont().getSize2D()-2));
	}
	
}
