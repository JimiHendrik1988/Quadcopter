package de.lazyzero.kkMulticopterFlashTool.gui.widgets;

import java.awt.Color;
import java.awt.event.FocusListener;

import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.MaskFormatter;

import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

public class JNamedIntMenuItem extends JPanel {

	private static final long serialVersionUID = 1L;
	private CellConstraints cc;
	private String label;
	private JLabel marker;
	private JFormattedTextField valueField;
	private MaskFormatter mf;
	private FocusListener listener;

	public JNamedIntMenuItem(String label, FocusListener listener) {
		this.label = label;
		this.listener = listener;
		init();
	}

	private void init() {
		//create the CellContraints
		cc  = new CellConstraints();
		
		// create the Layout for Panel this
		String panelColumns = "pref,3dlu,fill:pref:grow";
		String panelRows = "pref";
		FormLayout panelLayout = new FormLayout(panelColumns, panelRows);
		this.setLayout(panelLayout);
		
		this.marker = new JLabel(label+":");
		this.valueField = new JFormattedTextField();
		if (this.valueField.getBackground().equals(Color.BLACK)) {
			this.valueField.setBackground(Color.WHITE);
		}
		
		try {
		        mf = new MaskFormatter ("##");
		} catch (java.text.ParseException e) {
			
		}
		javax.swing.text.DefaultFormatterFactory dff = new  DefaultFormatterFactory(mf);
		valueField.setFormatterFactory(dff);
		valueField.addFocusListener(listener);
		
		this.add(marker, cc.xy(1, 1));
		this.add(valueField, cc.xy(3,1));
	}
	
	public void setValue(int value) {
		valueField.setText(value+"");
	}
	
	public int getValue() {
		return Integer.parseInt(valueField.getText().trim());
	}
}
