package de.lazyzero.kkMulticopterFlashTool.gui.widgets;

import static lu.tudor.santec.i18n.Translatrix._;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

public class PotEvaluationPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private CellConstraints cc;
	private JLabel adcRollPotLabel;
	private JLabel adcPitchPotLabel;
	private JTextField adcRollPotValue;
	private JLabel adcYawPotLabel;
	private JTextField adcPitchPotValue;
	private JTextField adcYawPotValue;

	public PotEvaluationPanel() {
		initGUI();
	}

	private void initGUI() {
		// create the CellContraints
		cc = new CellConstraints();

		// create the Layout for Panel this
		String panelColumns = "3dlu,pref:grow,3dlu";
		String panelRows = "3dlu,pref,3dlu,pref,3dlu,pref,3dlu,pref,3dlu,pref,3dlu,pref,3dlu,pref,3dlu";
		FormLayout panelLayout = new FormLayout(panelColumns, panelRows);
		this.setLayout(panelLayout);
		
		this.setBorder(new TitledBorder(_("PotEvaluationPanel.title")));
		adcRollPotLabel = new JLabel(_("PotEvaluationPanel.adcRollPot") + ":");
		adcPitchPotLabel = new JLabel(_("PotEvaluationPanel.adcPitchPot") + ":");
		adcYawPotLabel = new JLabel(_("PotEvaluationPanel.adcYawPot") + ":");
		
		adcRollPotValue = new JTextField();
		adcPitchPotValue = new JTextField();
		adcYawPotValue = new JTextField();
		
		adcRollPotValue.setEditable(false);
		adcPitchPotValue.setEditable(false);
		adcYawPotValue.setEditable(false);
		
		this.add(adcRollPotLabel, cc.xy(2, 2));
		this.add(adcRollPotValue, cc.xy(2, 4));
		this.add(adcPitchPotLabel, cc.xy(2, 6));
		this.add(adcPitchPotValue, cc.xy(2, 8));
		this.add(adcYawPotLabel, cc.xy(2, 10));
		this.add(adcYawPotValue, cc.xy(2, 12));
	}

	public void setRollPot(String roll) {
		adcRollPotValue.setText(roll);
	}

	public void setPitchPot(String pitch) {
		adcPitchPotValue.setText(pitch);
	}

	public void setYawPot(String yaw) {
		adcYawPotValue.setText(yaw);
	}
	
}
