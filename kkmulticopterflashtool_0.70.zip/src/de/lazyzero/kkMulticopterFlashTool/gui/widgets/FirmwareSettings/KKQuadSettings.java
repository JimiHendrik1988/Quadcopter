package de.lazyzero.kkMulticopterFlashTool.gui.widgets.FirmwareSettings;

import static lu.tudor.santec.i18n.Translatrix._;

import java.util.LinkedHashMap;
import java.util.logging.Logger;

import javax.swing.JLabel;
import javax.swing.JPanel;

import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

import de.lazyzero.kkMulticopterFlashTool.KKMulticopterFlashTool;
import de.lazyzero.kkMulticopterFlashTool.gui.widgets.EEpromFirmwareSettings;
import de.lazyzero.kkMulticopterFlashTool.gui.widgets.EEpromItemPanel;
import de.lazyzero.kkMulticopterFlashTool.utils.EEprom.EEpromBooleanItem;

public class KKQuadSettings extends EEpromFirmwareSettings {

	Logger logger = KKMulticopterFlashTool.getLogger();
	private EEpromBooleanItem rollGyro;
	private EEpromBooleanItem nickGyro;
	private EEpromBooleanItem yawGyro;
	private EEpromBooleanItem potDirection;

	public KKQuadSettings(KKMulticopterFlashTool parent) {
		super(parent);
	}

	@Override
	public String toString() {
		return "KapteinKuk Quadrocopter \u22644.7";
	}

	@Override
	protected JPanel addEEpromDataItems() {
		readEEprom(this);
		
		JPanel settingsPanel = new JPanel();
		LinkedHashMap<Short, String> dataMapping = new LinkedHashMap<Short, String>();
		dataMapping.put((short) 127, "true");
		dataMapping.put((short) 255, "false");
		
		wait4EEprom();
		
		// create the CellContraints
		CellConstraints cc = new CellConstraints();
		
		// create the Layout for Panel this
		String panelColumns = "fill:pref:grow,3dlu,fill:pref:grow,3dlu,fill:pref:grow";
		String panelRows = "pref,3dlu,pref";
		FormLayout panelLayout = new FormLayout(panelColumns, panelRows);
		settingsPanel.setLayout(panelLayout);
		
		if (eeprom != null) {
			rollGyro = new EEpromBooleanItem(eeprom, "Roll gyro", 0, 1, EEpromBooleanItem.BOOLEAN, dataMapping , "inverted");
			nickGyro = new EEpromBooleanItem(eeprom, "Nick gyro", 1, 1, EEpromBooleanItem.BOOLEAN, dataMapping , "inverted");
			yawGyro = new EEpromBooleanItem(eeprom, "Yaw gyro", 2, 1, EEpromBooleanItem.BOOLEAN, dataMapping , "inverted");
			
			potDirection = new EEpromBooleanItem(eeprom, "Pot direction", 3, 1, EEpromBooleanItem.BOOLEAN, dataMapping , "inverted");
			
			settingsPanel.add(new EEpromItemPanel(rollGyro), cc.xy(1, 1));
			settingsPanel.add(new EEpromItemPanel(nickGyro), cc.xy(3, 1));
			settingsPanel.add(new EEpromItemPanel(yawGyro), cc.xy(5, 1));
			settingsPanel.add(new EEpromItemPanel(potDirection), cc.xy(1, 3));
		} else {
			settingsPanel.add(new JLabel(_("EEPromSettingsPanel.failed2read")), cc.xyw(1, 1, 5));
		}
		
		return settingsPanel;
	}

	@Override
	public void flashSettings() {
		if (rollGyro != null && nickGyro != null && yawGyro != null) {
			logger.info("Write back settings to eeprom object.");
			eeprom = rollGyro.updateEEprom(eeprom);
			eeprom = nickGyro.updateEEprom(eeprom);
			eeprom = yawGyro.updateEEprom(eeprom);
			eeprom = potDirection.updateEEprom(eeprom);
			
			writeEEprom(this);
		}
	}


}
