package de.lazyzero.kkMulticopterFlashTool.gui;

import java.util.LinkedHashMap;

public interface SeriealListener {
	
	public void dataReceived(LinkedHashMap<String, String> data);

}
