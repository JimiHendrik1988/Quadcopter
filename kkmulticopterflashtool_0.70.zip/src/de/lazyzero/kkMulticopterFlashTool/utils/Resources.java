package de.lazyzero.kkMulticopterFlashTool.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class Resources {
	/**
		 * @param resourceAsStream
		 * @param outFile
		 * @throws Exception
		 */
		public static void writeStreamToFile(InputStream resourceAsStream, File 
	outFile) throws Exception {
			/* ================================================== */
		    FileOutputStream fos = new FileOutputStream(outFile);
		    try {
		        byte[] buf = new byte[1024];
		        int i = 0;
		        while ((i = resourceAsStream.read(buf)) != -1) {
		            fos.write(buf, 0, i);
		        }
		    } 
		    catch (Exception e) {
		        throw e;
		    }
		    finally {
		        fos.close();
		    }
			/* ================================================== */
		}
	
}

