package de.lazyzero.kkMulticopterFlashTool.utils;



public interface ButtonsStateListener {
	public void setButtonsEnabled(boolean b);
	public void updateButtons();
}
