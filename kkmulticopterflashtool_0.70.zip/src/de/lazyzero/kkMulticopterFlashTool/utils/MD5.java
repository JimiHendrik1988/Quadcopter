package de.lazyzero.kkMulticopterFlashTool.utils;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MD5 {
	
	public static void main (String[] arg) {
//		getMD5(new File(arg[0]));
//		getMD5(new File("/Users/moll/Downloads/QuadControllerV4_5/ich_Quad_03.hex"));
		
		File path = new File("/Users/moll/Library/Preferences/kkMulticopterFlashTool/_conf/");
		File[] files = path.listFiles();
		for (int i = 0; i < files.length; i++) {
			if (files[i].getAbsolutePath().endsWith(".eep")) {
				System.out.print(files[i]+ ": ");
				getMD5((files[i]));
			}
		}
		
	}
	
	public static String getMD5(File file) {
		MessageDigest digest = null;
		try {
			digest = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
		InputStream fis = new FileInputStream(file);
		DataInputStream dis = new DataInputStream(fis);
		
		while (dis.available()!=0) {
				digest.update(dis.readByte());
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		byte[] md5sum = digest.digest();
		BigInteger bigInt = new BigInteger(1, md5sum);
		String output = bigInt.toString(16);
		System.out.println("MD5: " + output);
		return output;
		
		
	}
}
