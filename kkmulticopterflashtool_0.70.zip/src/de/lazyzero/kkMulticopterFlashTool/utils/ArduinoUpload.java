package de.lazyzero.kkMulticopterFlashTool.utils;

import avr8_burn_o_mat.AVR;
import avr8_burn_o_mat.AvrdudeProgrammer;

public class ArduinoUpload {
private String name;
private AVR avr;
private AvrdudeProgrammer avrProgrammer;
private int speed;
	
	public ArduinoUpload(String name, AVR avr, AvrdudeProgrammer avrProgrammer, int speed) {
		this.setName(name);
		this.setAVR(avr);
		this.setAvrProgrammer(avrProgrammer);
		this.setSpeed(speed);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public AVR getAVR() {
		return avr;
	}

	public void setAVR(AVR avr) {
		this.avr = avr;
	}

	public AvrdudeProgrammer getAvrProgrammer() {
		return avrProgrammer;
	}

	public void setAvrProgrammer(AvrdudeProgrammer avrProgrammer) {
		this.avrProgrammer = avrProgrammer;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}
}


