package de.lazyzero.kkMulticopterFlashTool.utils;

public class FileCorruptException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public FileCorruptException() {
		super("File corrupt. MD5 does not match.");
	}
}
