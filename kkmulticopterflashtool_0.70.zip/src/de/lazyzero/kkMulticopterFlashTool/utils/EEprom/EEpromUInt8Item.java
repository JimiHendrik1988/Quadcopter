package de.lazyzero.kkMulticopterFlashTool.utils.EEprom;

import java.util.LinkedHashMap;

public class EEpromUInt8Item extends EEpromDataItem {
	

	public EEpromUInt8Item(EEprom eeprom, String type, int startAddress,
			int length, int dataType, boolean isEditable,
			String label) {
		super(eeprom, type, startAddress, length, dataType, isEditable, label);
	}

	/**
	 * set's the value on the EEpromDataItem using a mapping or direct values.
	 * @param number
	 * @return true, if the Item was updated.
	 */
	public boolean setValue(int number) throws EEpromValueException{
		
		if (value.length == 1) {
			value[0] = (short)number;
		} else {
			new EEpromValueException(EEpromValueException.VALUE_TOO_MUCH_ELEMENTS);
			return false;
		}
		return true;
	}

	public int getValue() {
		return value[0];
	}
	

}
