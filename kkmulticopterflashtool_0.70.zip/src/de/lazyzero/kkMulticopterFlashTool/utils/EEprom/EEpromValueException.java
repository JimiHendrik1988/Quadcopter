package de.lazyzero.kkMulticopterFlashTool.utils.EEprom;

public class EEpromValueException extends Exception {
	
	private static final long serialVersionUID = 1L;
	public static final String VALUE_TOO_MUCH_ELEMENTS = "To much elements in eeprom, only one element expected.";

	public EEpromValueException(String reason) {
		super(reason);
	}
}
