package de.lazyzero.kkMulticopterFlashTool.utils.EEprom;

import java.util.Iterator;
import java.util.LinkedHashMap;


public class EEpromBooleanItem extends EEpromDataItem {
	
	public EEpromBooleanItem(EEprom eeprom, String type, int startAddress, int length, int dataType, LinkedHashMap<Short, String> dataMapping, String label) {
		super(eeprom, type, startAddress, length, dataType, dataMapping, label);
	}
	
	public boolean getValue() throws EEpromValueException{
		if (value.length == 1) {
			return Boolean.valueOf(dataMapping.get(value[0]));
		} else {
			new EEpromValueException(EEpromValueException.VALUE_TOO_MUCH_ELEMENTS);
			return false;
		}
		 
	}
	
	public boolean setValue(boolean bool) {
		if(dataMapping.containsValue(bool+"")){
			
			for (Iterator iterator = dataMapping.keySet().iterator(); iterator.hasNext();) {
				Short key = (Short) iterator.next();
				if (dataMapping.get(key).equals(bool+"")){
					value[0] = key;
					return true;
				}
			}
		} 

		return false;
	}

}
