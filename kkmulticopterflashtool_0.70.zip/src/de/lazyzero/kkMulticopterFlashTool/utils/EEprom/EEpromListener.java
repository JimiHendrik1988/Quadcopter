package de.lazyzero.kkMulticopterFlashTool.utils.EEprom;

public interface EEpromListener {
	
	int READ = 0;
	int FAILED = -1;
	int WROTE = 1;
	int FILE_CORRUPT = -2;
	int FLASH_FAILED = -3;

	public void EEpromState(int state);

}
