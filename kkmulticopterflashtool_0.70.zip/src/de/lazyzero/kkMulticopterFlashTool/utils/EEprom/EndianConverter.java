package de.lazyzero.kkMulticopterFlashTool.utils.EEprom;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class EndianConverter {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(convertLittleEndianToUInt16((byte)0x84, (byte)0x03));
		
		byte[] b = convertUInt16ToBigEndian(900);
		for (byte c : b) {
			System.out.println(c);
		}
		System.out.println(convertLittleEndianToUInt16(b[0], b[1]));
	}

	
	public static int convertLittleEndianToUInt16(byte low, byte high) {
		byte[] b = { low, high,  0x00, 0x00};
		ByteBuffer bb = ByteBuffer.wrap(b);
		bb = bb.order(ByteOrder.LITTLE_ENDIAN);
		return bb.getInt();
	}
	
	public static byte[] convertUInt16ToBigEndian(int value) {
		byte[] b = { 0x00, 0x00,  0x00, 0x00};
		b[0] = (byte) (value & 0xFF);
		b[1] = (byte) ((value >> 8) & 0xFF);
		ByteBuffer bb = ByteBuffer.wrap(b);
		bb = bb.order(ByteOrder.BIG_ENDIAN);
		return bb.array();
	}
	
}
