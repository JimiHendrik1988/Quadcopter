package de.lazyzero.kkMulticopterFlashTool.RepositoryTool;

import java.awt.Dimension;
import java.util.Vector;

import javax.swing.JTable;

import de.lazyzero.kkMulticopterFlashTool.utils.Firmware;

public class FirmwareTablePanel extends JTable{

	private static final long serialVersionUID = 1L;
	private FirmwareTableModel tableModel;

	public FirmwareTablePanel(Vector<Firmware> firmwares) {
		
		this.tableModel = new FirmwareTableModel(firmwares);
		this.setModel(tableModel);
		
		this.setAutoCreateRowSorter(true);
        this.setFillsViewportHeight(true);
		
	}

}
