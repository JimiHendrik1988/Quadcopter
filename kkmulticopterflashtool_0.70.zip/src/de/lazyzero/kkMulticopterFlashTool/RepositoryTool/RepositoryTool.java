package de.lazyzero.kkMulticopterFlashTool.RepositoryTool;

import static lu.tudor.santec.i18n.Translatrix._;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import de.lazyzero.kkMulticopterFlashTool.utils.Firmware;
import de.lazyzero.kkMulticopterFlashTool.utils.XmlReaderFirmwares;

public class RepositoryTool extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private static final String VERSION = "0.1";
	private JTable firmwareTablePanel;
	private Vector<Firmware> firmwares;
	private XmlReaderFirmwares firmwareReader;

	public RepositoryTool() {
		init();
		initGUI();
	}

	private void init() {
		firmwares = new Vector<Firmware>();
		try {
			firmwareReader = new XmlReaderFirmwares(new URL("http://lazyzero.de/_media/firmwares.xml.zip"), new URL("http://lazyzero.de/_media/firmwares.xml.zip"));
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		firmwares.addAll(firmwareReader.getFirmwares());
		
	}

	private void initGUI() {
		this.setTitle(_("title") + " " + VERSION + ": KKFlashtool stable Version: " + firmwareReader.getActualVersion());
		
		
		firmwareTablePanel = new FirmwareTablePanel(firmwares);
		
		this.add(new JScrollPane(firmwareTablePanel));
		this.pack();
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new RepositoryTool();
	}

}
