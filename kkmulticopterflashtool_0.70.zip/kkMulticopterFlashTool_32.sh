#!/bin/sh

cd $(dirname $0)
cp ./lib/linux32/librxtxSerial.so ./lib/librxtxSerial.so
java -Djava.library.path=.:./lib/ -jar kkMulticopterFlashTool.jar
